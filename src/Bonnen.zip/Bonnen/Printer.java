

/**
 * Created by Kirty on 31/03/2017.
 */
import java.awt.*;
import java.awt.print.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ImageIcon;

public class Printer
{
    public double amount;

    public Printer(double money)
    {
        amount = money;
    }

    public void preview()
    {
        JFrame frame = new JFrame();

        frame.setTitle("Preview for label");
        frame.setSize(300, 400);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        frame.add(new PrintPreview());
    }

    public void print(boolean noDialog)
    {
        PrinterJob job = PrinterJob.getPrinterJob();
        PageFormat page = new PageFormat();
        Paper paper = new Paper();

        paper.setImageableArea(0, 0, 160, 290);
        paper.setSize(160, 290);

        page.setPaper(paper);

        job.setPrintable(new OutPrintable(), page);

        try
        {
            if (noDialog)
                job.print();
            else
            {
                if (job.printDialog())
                    job.print();
            }
        }
        catch (Exception e)
        {
            System.out.println("Error while printing: " + e.getMessage());
        }
    }

    public void createLabel(Graphics2D graphics)
    {
        graphics.setColor(Color.white);
        graphics.fillRect(0, 0, 160, 280);

        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Image img = new ImageIcon("/Users/Kirty/IdeaProjects/PrinterDemo/src/ff.png").getImage();
        graphics.drawImage(img, 10, 30, 90, 90, null);

        graphics.setColor(Color.black);

        graphics.setFont(new Font("Roboto", Font.BOLD, 18));
        graphics.drawString("PsyBank", 55, 34);

        graphics.setFont(new Font("Roboto", Font.PLAIN, 14));
        graphics.drawString("Dé bank voor u!", 55, 50);

        graphics.drawLine(5, 60, 150, 60);



        graphics.drawLine(5, 240, 150, 240);

        graphics.setFont(new Font("Monospace", Font.PLAIN, 10));
        graphics.drawString("Bedankt en tot ziens", 30, 255);
        graphics.drawString("kijk ook eens op psybank.ml", 10, 270);
    }

    class OutPrintable implements Printable
    {
        public int print(Graphics g, PageFormat pf, int pageIndex)
        {
            if (pageIndex != 0)
                return NO_SUCH_PAGE;

            Graphics2D graphics = (Graphics2D)g;

            createLabel(graphics);

            return PAGE_EXISTS;
        }
    }

    class PrintPreview extends JPanel
    {
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);

            Graphics2D graphics = (Graphics2D)g;

            createLabel(graphics);
        }
    }
}
