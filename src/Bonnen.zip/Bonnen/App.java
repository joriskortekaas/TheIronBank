

/**
 * Created by Kirty on 31/03/2017.
 */
public class App {

    public static void main(String[] args) {

        System.out.println("Printing the print");

        Printer printer = new Printer(50);

        printer.print(true);
    }
}
